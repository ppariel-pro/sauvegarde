# Role 'TEST_PPA'

Description du role ici

## Prerequis

## Variables

Les variables par defaut du role se trouvent [ici](defaults/main.yml).

| **Variable**       | **Valeur par Defaut**  | **Commentaires**                                   |
|--------------------|------------------------|----------------------------------------------------|

## Dependances

  * [aans0](http://dlzuteggsc12.yres.ytech/ansible/ansible-role-aans0)

## Exemple(s) d'utilisation

```yaml
---
- hosts: test_ppa_servers

  roles:
    - aans0 # Role Ansible Socle
    - test_ppa
```

## Auteur(s)

Prenom Nom < @ca-gip.fr>